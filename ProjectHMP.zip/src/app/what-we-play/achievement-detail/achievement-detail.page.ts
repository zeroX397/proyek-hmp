import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-achievement-detail',
  templateUrl: './achievement-detail.page.html',
  styleUrls: ['./achievement-detail.page.scss'],
})
export class AchievementDetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
